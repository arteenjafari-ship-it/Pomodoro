package com.example.pomodoro

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.text.InputFilter
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

fun c(s: String): Int = Color.parseColor(s)
fun wa(color: Int, a: Int): Int = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

class AppTheme(
    val name: String, val bg1: Int, val bg2: Int, val card: Int,
    val accent: Int, val onAccent: Int, val text: Int,
    val skin: Int, val hair: Int, val shirt: Int, val desk: Int
)

val THEMES = listOf(
    AppTheme("شب", c("#14142B"), c("#2B2A5C"), c("#2A2956"), c("#FFC857"), c("#2B2000"), c("#FFFFFF"),
        c("#FFD7B5"), c("#3B2A4A"), c("#6C8CFF"), c("#8B5E3C")),
    AppTheme("شکوفه", c("#FFE5EC"), c("#FFB3C6"), c("#FFF7FA"), c("#FB6F92"), c("#FFFFFF"), c("#4A2040"),
        c("#FFE0C8"), c("#5B3A29"), c("#B8A1FF"), c("#C98B5E")),
    AppTheme("جنگل", c("#0B3D2E"), c("#1F7A5A"), c("#14523F"), c("#B7F7C5"), c("#0B3D2E"), c("#FFFFFF"),
        c("#F6CBA6"), c("#2B1B12"), c("#FF9F68"), c("#7A5230"))
)

// ---------------------------------------------------------------- آدمک همدرس
class StudyView(ctx: Context) : View(ctx) {
    var theme: AppTheme = THEMES[0]
    var mode = 0          // 0 آماده، 1 تمرکز، 2 استراحت، 3 تمام شد
    var buddy = "میمی"

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val t0 = SystemClock.uptimeMillis()
    private val dark = c("#2B2230")
    private val conf = listOf(c("#FF6B9A"), c("#6EC6FF"), c("#9CFFB0"), c("#FFD23F"))

    private val idleMsgs = listOf("سلام! بیا با هم درس بخونیم", "من آماده‌ام، تو چی؟", "یه جلسه تمرکز شروع کنیم؟")
    private val focusMsgs = listOf("هیس... دارم می‌نویسم", "عالی پیش می‌ری!", "گوشی رو فراموش کن", "یه قدم دیگه نزدیک‌تر شدی", "تمرکزت قشنگه", "ادامه بده، من کنارتم")
    private val breakMsgs = listOf("یه کم آب بخور", "چشم‌هات رو استراحت بده", "یه نفس عمیق بکش", "کمی کشش بده")
    private val doneMsgs = listOf("آفرین! تموم شد!", "تو فوق‌العاده‌ای!", "این جلسه رو ترکوندی!")

    private fun fill(color: Int) { p.style = Paint.Style.FILL; p.color = color }
    private fun stroke(color: Int, w: Float) {
        p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
    }

    private fun message(t: Float): String {
        val list = when (mode) { 1 -> focusMsgs; 2 -> breakMsgs; 3 -> doneMsgs; else -> idleMsgs }
        return list[(t / 6f).toInt() % list.size]
    }

    override fun onDraw(canvas: Canvas) {
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val s = min(width / 100f, height / 112f)
        canvas.save()
        canvas.translate(width / 2f, height.toFloat())
        canvas.scale(s, s)

        // هاله پشت آدمک
        fill(wa(theme.accent, 30)); canvas.drawCircle(0f, -50f, 46f, p)

        // ستاره‌ها
        for (i in 0 until 14) {
            var x = ((i * 47) % 80) - 40f
            if (abs(x) < 24f) x += if (x < 0f) -26f else 26f
            x = x.coerceIn(-47f, 47f)
            val y = -(35f + (i * 29) % 52)
            val a = (70 + 185 * abs(sin(t * 1.3f + i))).toInt()
            fill(wa(theme.accent, a)); canvas.drawCircle(x, y, 0.7f + (i % 3) * 0.4f, p)
        }

        // بدن
        fill(theme.shirt); canvas.drawRoundRect(RectF(-18f, -54f, 18f, -20f), 10f, 10f, p)
        fill(wa(Color.WHITE, 210))
        path.reset(); path.moveTo(-5f, -54f); path.lineTo(0f, -48f); path.lineTo(5f, -54f); path.close()
        canvas.drawPath(path, p)

        // مو (پشت)
        fill(theme.hair)
        canvas.drawCircle(0f, -66f, 15.5f, p)
        canvas.drawCircle(-14f, -79f, 5f, p)
        canvas.drawCircle(14f, -79f, 5f, p)
        fill(theme.accent); canvas.drawCircle(-14f, -79f, 1.8f, p)

        // صورت
        fill(theme.skin); canvas.drawCircle(0f, -62f, 13.5f, p)

        // چتری
        fill(theme.hair)
        path.reset()
        path.moveTo(-14f, -63f)
        path.quadTo(-14.5f, -77f, 0f, -77f)
        path.quadTo(14.5f, -77f, 14f, -63f)
        path.quadTo(8f, -72f, 0f, -68f)
        path.quadTo(-8f, -72f, -14f, -63f)
        path.close()
        canvas.drawPath(path, p)

        // چشم‌ها
        val ey = -62f
        val blink = (t % 4f) < 0.14f
        for (sx in listOf(-5f, 5f)) {
            if (mode == 3) {
                stroke(dark, 1.3f)
                canvas.drawArc(RectF(sx - 2.2f, ey - 1.5f, sx + 2.2f, ey + 2.5f), 180f, 180f, false, p)
            } else if (blink) {
                stroke(dark, 1.2f); canvas.drawLine(sx - 2f, ey, sx + 2f, ey, p)
            } else {
                val dy = if (mode == 1) 0.8f else 0f
                fill(dark); canvas.drawCircle(sx, ey + dy, 1.9f, p)
                fill(Color.WHITE); canvas.drawCircle(sx + 0.6f, ey + dy - 0.6f, 0.6f, p)
            }
        }
        // گونه‌ها
        fill(wa(c("#FF7A93"), 95))
        canvas.drawCircle(-8.5f, -57.5f, 2.6f, p); canvas.drawCircle(8.5f, -57.5f, 2.6f, p)
        // دهان
        if (mode == 3) {
            fill(c("#7A2E3A")); canvas.drawArc(RectF(-3.5f, -59f, 3.5f, -52.5f), 0f, 180f, true, p)
        } else if (mode == 1) {
            stroke(dark, 1f); canvas.drawLine(-1.5f, -55.5f, 1.5f, -55.5f, p)
        } else {
            stroke(dark, 1f); canvas.drawArc(RectF(-3f, -58f, 3f, -54f), 20f, 140f, false, p)
        }

        // میز
        fill(theme.desk); canvas.drawRoundRect(RectF(-50f, -26f, 50f, -17f), 2f, 2f, p)
        fill(wa(Color.BLACK, 45)); canvas.drawRect(-50f, -17f, 50f, 0f, p)
        fill(theme.desk); canvas.drawRect(-50f, -17f, 50f, -15f, p)
        // اسم همدرس روی میز
        fill(wa(Color.WHITE, 215)); canvas.drawRoundRect(RectF(-13f, -12f, 13f, -4f), 4f, 4f, p)
        fill(dark); p.textAlign = Paint.Align.CENTER; p.textSize = 4.6f; p.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText(buddy, 0f, -6.6f, p)

        // نور چراغ
        fill(wa(c("#FFE9A8"), 38))
        path.reset(); path.moveTo(27f, -50f); path.lineTo(6f, -26f); path.lineTo(36f, -26f); path.close()
        canvas.drawPath(path, p)

        // کتاب
        fill(c("#FFFDF5"))
        path.reset(); path.moveTo(-15f, -26f); path.lineTo(-1f, -26f); path.lineTo(-1f, -33f); path.lineTo(-15f, -31f); path.close()
        canvas.drawPath(path, p)
        path.reset(); path.moveTo(1f, -26f); path.lineTo(15f, -26f); path.lineTo(15f, -31f); path.lineTo(1f, -33f); path.close()
        canvas.drawPath(path, p)
        stroke(wa(dark, 90), 0.6f)
        for (k in 0..2) {
            val ly = -29.5f + k * 1.4f
            canvas.drawLine(-12.5f, ly, -3f, ly + 0.5f, p)
            canvas.drawLine(3f, ly + 0.5f, 12.5f, ly, p)
        }
        stroke(wa(dark, 120), 0.8f); canvas.drawLine(0f, -33f, 0f, -26f, p)

        // لیوان و بخار
        fill(Color.WHITE); canvas.drawRoundRect(RectF(-37f, -34f, -29f, -26f), 1.5f, 1.5f, p)
        stroke(Color.WHITE, 1.1f); canvas.drawArc(RectF(-31f, -32f, -26.5f, -28f), -90f, 180f, false, p)
        for (k in 0..1) {
            val bx = -35f + k * 4f
            stroke(wa(theme.text, 110), 0.8f)
            canvas.drawLine(bx, -36f, bx + sin(t * 2f + k) * 1.6f, -41f, p)
        }

        // چراغ مطالعه
        fill(wa(Color.BLACK, 120)); canvas.drawRoundRect(RectF(26f, -28f, 38f, -26f), 1f, 1f, p)
        stroke(wa(Color.BLACK, 140), 1.2f)
        canvas.drawLine(32f, -27f, 38f, -45f, p); canvas.drawLine(38f, -45f, 28f, -52f, p)
        fill(theme.accent)
        path.reset(); path.moveTo(23f, -54f); path.lineTo(33f, -50f); path.lineTo(26f, -45f); path.close()
        canvas.drawPath(path, p)

        // دست راست (مداد به دست)
        val rhx: Float; val rhy: Float
        when (mode) {
            1 -> { rhx = 7f + sin(t * 7f) * 1.8f; rhy = -28.5f + cos(t * 14f) * 0.4f }
            3 -> { rhx = 25f + sin(t * 8f) * 3f; rhy = -72f + cos(t * 8f) * 2f }
            else -> { rhx = 8f; rhy = -28.5f }
        }
        stroke(theme.shirt, 6.5f); canvas.drawLine(14f, -47f, rhx, rhy, p)
        fill(theme.skin); canvas.drawCircle(rhx, rhy, 3.2f, p)
        if (mode != 3) {
            stroke(c("#FFD23F"), 1.8f); canvas.drawLine(rhx - 1.5f, rhy + 3.5f, rhx + 5f, rhy - 7f, p)
            fill(dark); canvas.drawCircle(rhx - 1.5f, rhy + 3.5f, 0.9f, p)
        }
        // دست چپ
        val lhx: Float; val lhy: Float
        if (mode == 3) { lhx = -25f + sin(t * 8f + 1f) * 3f; lhy = -72f + cos(t * 8f + 1f) * 2f }
        else { lhx = -8f; lhy = -28.5f }
        stroke(theme.shirt, 6.5f); canvas.drawLine(-14f, -47f, lhx, lhy, p)
        fill(theme.skin); canvas.drawCircle(lhx, lhy, 3.2f, p)

        // کاغذ رنگی
        if (mode == 3) {
            for (i in 0 until 18) {
                val x = ((i * 37) % 96) - 48f
                val y = -108f + (t * 28f + i * 17f) % 100f
                canvas.save()
                canvas.translate(x + sin(t * 2f + i) * 3f, y)
                canvas.rotate((t * 3f + i) * 57.3f)
                fill(conf[i % conf.size]); canvas.drawRect(-1.2f, -0.7f, 1.2f, 0.7f, p)
                canvas.restore()
            }
        }

        // حباب حرف
        val msg = message(t)
        p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER; p.textSize = 5.2f
        var tw = p.measureText(msg)
        if (tw > 84f) { p.textSize = 5.2f * 84f / tw; tw = 84f }
        val bw = tw + 10f
        fill(Color.WHITE); canvas.drawRoundRect(RectF(-bw / 2f, -109f, bw / 2f, -95f), 7f, 7f, p)
        path.reset(); path.moveTo(-3f, -95.2f); path.lineTo(3f, -95.2f); path.lineTo(0f, -91f); path.close()
        canvas.drawPath(path, p)
        fill(dark); canvas.drawText(msg, 0f, -100.2f, p)

        canvas.restore()
        postInvalidateDelayed(33)
    }
}

// ---------------------------------------------------------------- حلقه تایمر
class TimerView(ctx: Context) : View(ctx) {
    var theme: AppTheme = THEMES[0]
    var progress = 1f
    var timeText = "25:00"
    var label = "آماده"
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val cx = width / 2f; val cy = height / 2f
        val sw = size * 0.055f
        val r = size / 2f - sw
        p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.strokeCap = Paint.Cap.ROUND
        p.color = wa(theme.text, 40); canvas.drawCircle(cx, cy, r, p)
        p.color = theme.accent
        canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -90f, 360f * progress, false, p)
        p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.color = theme.text; p.typeface = Typeface.DEFAULT_BOLD; p.textSize = size * 0.24f
        canvas.drawText(timeText, cx, cy + size * 0.06f, p)
        p.typeface = Typeface.DEFAULT; p.color = wa(theme.text, 190); p.textSize = size * 0.085f
        canvas.drawText(label, cx, cy + size * 0.22f, p)
    }
}

// ---------------------------------------------------------------- صفحه اصلی
class MainActivity : Activity() {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var root: LinearLayout
    private lateinit var title: TextView
    private lateinit var stats: TextView
    private lateinit var menuBtn: TextView
    private lateinit var study: StudyView
    private lateinit var timerV: TimerView
    private lateinit var btn1: TextView
    private lateinit var btn2: TextView
    private var timer: CountDownTimer? = null
    private var ui = 0
    private var th: AppTheme = THEMES[0]
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    private val focusMin: Int get() = prefs.getInt("focus", 25)
    private val breakMin: Int get() = prefs.getInt("break", 5)
    private val buddyName: String get() = prefs.getString("name", "میمی") ?: "میمی"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        th = THEMES[prefs.getInt("theme", 0).coerceIn(0, THEMES.size - 1)]
        build()
        resume()
    }

    private fun build() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(20))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        title = TextView(this).apply { text = "همدرس"; textSize = 24f; typeface = Typeface.DEFAULT_BOLD }
        menuBtn = TextView(this).apply {
            text = "☰"; textSize = 22f; gravity = Gravity.CENTER
            setOnClickListener { showMenu() }
        }
        top.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(menuBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        stats = TextView(this).apply { textSize = 13f }
        study = StudyView(this)
        timerV = TimerView(this)
        btn1 = makeBtn(); btn2 = makeBtn()

        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(stats, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(study, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(timerV, LinearLayout.LayoutParams(MATCH, dp(190)))
        root.addView(btn1, LinearLayout.LayoutParams(MATCH, dp(56)).apply { topMargin = dp(8) })
        root.addView(btn2, LinearLayout.LayoutParams(MATCH, dp(52)).apply { topMargin = dp(8) })
        setContentView(root)
        applyTheme()
    }

    private fun makeBtn() = TextView(this).apply {
        gravity = Gravity.CENTER; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
    }

    private fun style(tv: TextView, filled: Boolean, enabled: Boolean) {
        tv.background = round(if (filled) th.accent else wa(th.text, 32), dp(28).toFloat())
        tv.setTextColor(if (filled) th.onAccent else th.text)
        tv.alpha = if (enabled) 1f else 0.55f
    }

    private fun applyTheme() {
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(th.bg1, th.bg2))
        title.setTextColor(th.text)
        menuBtn.setTextColor(th.text)
        stats.setTextColor(wa(th.text, 190))
        window.statusBarColor = th.bg1
        window.navigationBarColor = th.bg2
        val lightBg = Color.red(th.text) < 128
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (lightBg) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        refreshUi()
    }

    private fun refreshUi() {
        study.mode = ui; study.buddy = buddyName; study.theme = th
        timerV.theme = th
        timerV.label = when (ui) { 1 -> "تمرکز"; 2 -> "استراحت"; 3 -> "تمام شد!"; else -> "آماده" }
        when (ui) {
            0 -> {
                btn1.text = "شروع تمرکز  •  $focusMin دقیقه"
                btn1.setOnClickListener { startPhase(1) }
                style(btn1, true, true); btn2.visibility = View.GONE
            }
            1 -> {
                btn1.text = "تمرکز فعال؛ گوشی قفله"
                btn1.setOnClickListener { }
                style(btn1, true, false); btn2.visibility = View.GONE
            }
            2 -> {
                btn1.text = "برگردیم سر درس"
                btn1.setOnClickListener { endBreak() }
                style(btn1, true, true); btn2.visibility = View.GONE
            }
            else -> {
                btn1.text = "استراحت  •  $breakMin دقیقه"
                btn1.setOnClickListener { startPhase(2) }
                style(btn1, true, true)
                btn2.text = "جلسه بعدی، بدون استراحت"
                btn2.setOnClickListener { startPhase(1) }
                style(btn2, false, true); btn2.visibility = View.VISIBLE
            }
        }
        menuBtn.alpha = if (ui == 1) 0.3f else 1f
        val (ts, tm) = todayCounts()
        stats.text = "امروز: $ts جلسه  •  $tm دقیقه تمرکز"
        timerV.invalidate()
    }

    // ------------------------------------------------------------ منطق تایمر
    private fun setIdleTimer() {
        timerV.timeText = "%02d:00".format(focusMin); timerV.progress = 1f
    }

    private fun startPhase(m: Int) {
        val dur = (if (m == 1) focusMin else breakMin) * 60_000L
        prefs.edit().putInt("mode", m).putLong("end", System.currentTimeMillis() + dur).putLong("dur", dur).apply()
        runPhase()
    }

    private fun runPhase() {
        val m = prefs.getInt("mode", 0)
        val end = prefs.getLong("end", 0L)
        val dur = prefs.getLong("dur", 1L).coerceAtLeast(1L)
        ui = m
        if (m == 1) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            try { startLockTask() } catch (_: Exception) { }
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        refreshUi()
        timer?.cancel()
        val left = end - System.currentTimeMillis()
        updateTimer(left, dur)
        timer = object : CountDownTimer(left.coerceAtLeast(1L), 250) {
            override fun onTick(ms: Long) { updateTimer(ms, dur) }
            override fun onFinish() { phaseDone() }
        }.start()
    }

    private fun updateTimer(ms: Long, dur: Long) {
        val sec = (ms.coerceAtLeast(0L) + 999) / 1000
        timerV.timeText = "%02d:%02d".format(sec / 60, sec % 60)
        timerV.progress = (ms.toFloat() / dur).coerceIn(0f, 1f)
        timerV.invalidate()
    }

    private fun phaseDone() {
        val m = prefs.getInt("mode", 0)
        val minutes = (prefs.getLong("dur", 0L) / 60_000L).toInt()
        prefs.edit().putInt("mode", 0).putLong("end", 0L).apply()
        try { stopLockTask() } catch (_: Exception) { }
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (m == 1) {
            addStats(minutes)
            ui = 3; timerV.timeText = "00:00"; timerV.progress = 0f
            buzz(900)
        } else {
            ui = 0; setIdleTimer(); buzz(400)
        }
        refreshUi()
    }

    private fun endBreak() {
        timer?.cancel()
        prefs.edit().putInt("mode", 0).putLong("end", 0L).apply()
        ui = 0; setIdleTimer(); refreshUi()
    }

    private fun resume() {
        val m = prefs.getInt("mode", 0)
        if (m == 0) { ui = 0; setIdleTimer(); refreshUi(); return }
        if (prefs.getLong("end", 0L) > System.currentTimeMillis()) { runPhase(); return }
        val minutes = (prefs.getLong("dur", 0L) / 60_000L).toInt()
        prefs.edit().putInt("mode", 0).putLong("end", 0L).apply()
        if (m == 1) { addStats(minutes); ui = 3; timerV.timeText = "00:00"; timerV.progress = 0f }
        else { ui = 0; setIdleTimer() }
        refreshUi()
    }

    private fun buzz(ms: Long) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) { }
    }

    // ------------------------------------------------------------ آمار
    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun addStats(min: Int) {
        val e = prefs.edit()
        var s = prefs.getInt("tS", 0); var m = prefs.getInt("tM", 0)
        if (prefs.getString("day", "") != today()) { s = 0; m = 0; e.putString("day", today()) }
        e.putInt("tS", s + 1).putInt("tM", m + min)
            .putInt("aS", prefs.getInt("aS", 0) + 1).putInt("aM", prefs.getInt("aM", 0) + min).apply()
    }

    private fun todayCounts(): Pair<Int, Int> =
        if (prefs.getString("day", "") == today()) Pair(prefs.getInt("tS", 0), prefs.getInt("tM", 0)) else Pair(0, 0)

    // ------------------------------------------------------------ منو
    private fun chips(labels: List<String>, sel0: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = ArrayList<TextView>()
        var sel = sel0
        fun paint() {
            views.forEachIndexed { i, tv ->
                val on = i == sel
                tv.background = round(if (on) th.accent else wa(th.text, 28), dp(18).toFloat())
                tv.setTextColor(if (on) th.onAccent else th.text)
            }
        }
        labels.forEachIndexed { i, s ->
            val tv = TextView(this).apply {
                text = s; textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { sel = i; paint(); onPick(i) }
            }
            views.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(8) })
        }
        paint()
        return row
    }

    private fun showMenu() {
        if (ui == 1) return
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(16))
            background = round(th.card, dp(24).toFloat())
        }
        fun label(s: String) = TextView(this).apply {
            text = s; textSize = 14f; setTextColor(wa(th.text, 200)); setPadding(0, dp(14), 0, dp(6))
        }
        card.addView(TextView(this).apply {
            text = "منو"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(th.text)
        })

        card.addView(label("مدت تمرکز (دقیقه)"))
        val fo = listOf(15, 25, 45, 60)
        card.addView(chips(fo.map { it.toString() }, fo.indexOf(focusMin)) { i ->
            prefs.edit().putInt("focus", fo[i]).apply()
            if (ui == 0) setIdleTimer()
            refreshUi()
        })

        card.addView(label("مدت استراحت (دقیقه)"))
        val br = listOf(5, 10, 15)
        card.addView(chips(br.map { it.toString() }, br.indexOf(breakMin)) { i ->
            prefs.edit().putInt("break", br[i]).apply(); refreshUi()
        })

        card.addView(label("تم"))
        card.addView(chips(THEMES.map { it.name }, THEMES.indexOf(th)) { i ->
            prefs.edit().putInt("theme", i).apply()
            th = THEMES[i]
            applyTheme()
            d.dismiss()
            showMenu()
        })

        card.addView(label("اسم همدرست"))
        val nameEt = EditText(this).apply {
            setText(buddyName); setTextColor(th.text); textSize = 16f; isSingleLine = true
            filters = arrayOf(InputFilter.LengthFilter(12))
            background = round(wa(th.text, 28), dp(14).toFloat())
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        card.addView(nameEt, LinearLayout.LayoutParams(MATCH, WRAP))

        card.addView(label("آمار کل"))
        card.addView(TextView(this).apply {
            text = "${prefs.getInt("aS", 0)} جلسه  •  ${prefs.getInt("aM", 0)} دقیقه تمرکز"
            textSize = 15f; setTextColor(th.text)
        })

        val close = makeBtn().apply { text = "بستن"; setOnClickListener { d.dismiss() } }
        style(close, true, true)
        card.addView(close, LinearLayout.LayoutParams(MATCH, dp(48)).apply { topMargin = dp(18) })

        d.setOnDismissListener {
            val n = nameEt.text.toString().trim()
            if (n.isNotEmpty()) prefs.edit().putString("name", n).apply()
            refreshUi()
        }
        d.setContentView(ScrollView(this).apply { addView(card) })
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.show()
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.9).toInt(), WRAP)
    }

    @Deprecated("blocked while the focus timer runs")
    override fun onBackPressed() {
        if (ui != 1) @Suppress("DEPRECATION") super.onBackPressed()
    }
}
