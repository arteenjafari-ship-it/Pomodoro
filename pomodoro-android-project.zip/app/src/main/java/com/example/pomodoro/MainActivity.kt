package com.example.pomodoro

import android.app.Activity
import android.graphics.Color
import android.os.*
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    private lateinit var timeText: TextView
    private lateinit var btn: Button
    private lateinit var input: EditText
    private var timer: CountDownTimer? = null
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.parseColor("#1B1B1F"))
        }
        timeText = TextView(this).apply {
            textSize = 72f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; text = "25:00"
        }
        input = EditText(this).apply {
            setText("25"); gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = "دقیقه"
        }
        btn = Button(this).apply { text = "شروع تمرکز" ; setOnClickListener { start() } }
        root.addView(timeText); root.addView(input); root.addView(btn)
        setContentView(root)

        val end = prefs.getLong("end", 0L)
        if (end > System.currentTimeMillis()) run(end)
    }

    private fun start() {
        val min = input.text.toString().toLongOrNull()?.coerceIn(1, 180) ?: 25
        val end = System.currentTimeMillis() + min * 60_000
        prefs.edit().putLong("end", end).apply()
        run(end)
    }

    private fun run(end: Long) {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        input.visibility = View.GONE
        btn.visibility = View.GONE
        try { startLockTask() } catch (_: Exception) {}
        timer?.cancel()
        timer = object : CountDownTimer(end - System.currentTimeMillis(), 1000) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                timeText.text = "%02d:%02d".format(s / 60, s % 60)
            }
            override fun onFinish() { finish_() }
        }.start()
    }

    private fun finish_() {
        prefs.edit().putLong("end", 0L).apply()
        try { stopLockTask() } catch (_: Exception) {}
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        timeText.text = "تمام شد! 🎉"
        input.visibility = View.VISIBLE
        btn.visibility = View.VISIBLE
        val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    @Deprecated("blocked while timer runs")
    override fun onBackPressed() {
        if (prefs.getLong("end", 0L) <= System.currentTimeMillis()) super.onBackPressed()
    }
}
